-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2024 at 10:05 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculateTotalPrice` (IN `productID` VARCHAR(4), IN `quantity` INT)   BEGIN
    DECLARE totalOrderPrice DECIMAL(10, 2);

    SELECT SUM(orderQuantity * productPrice) INTO totalOrderPrice
    FROM OrderDetail OD
    JOIN Product P ON OD.productID = P.productID
    WHERE OD.productID = productID;

    SELECT CONCAT('Total order price: ', totalOrderPrice);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `beverage`
--

CREATE TABLE `beverage` (
  `beverageID` varchar(4) NOT NULL,
  `drinkType` enum('Hot','Iced') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `beverage`
--

INSERT INTO `beverage` (`beverageID`, `drinkType`) VALUES
('P002', 'Iced'),
('P003', 'Iced'),
('P004', 'Iced');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` varchar(4) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `customerEmail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `customerName`, `customerEmail`) VALUES
('C001', 'alfons', 'alfons@gmail.com'),
('C002', 'jovanda', 'jovanda@gmail.com'),
('C003', 'evorius@gmail.com', 'evorius@gmail.com'),
('C004', 'evo', 'atilaganteng@gmail.com'),
('C005', 'vincent', 'vincent@gmail.com'),
('C006', 'william@gmail.com', 'william@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `foodID` varchar(4) NOT NULL,
  `foodType` enum('Main Course','Snacks','Desserts') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`foodID`, `foodType`) VALUES
('P001', 'Desserts'),
('P005', 'Main Course');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `orderDetailID` varchar(32) NOT NULL,
  `orderID` varchar(4) NOT NULL,
  `productID` varchar(4) NOT NULL,
  `orderQuantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`orderDetailID`, `orderID`, `productID`, `orderQuantity`) VALUES
('O001P001', 'O001', 'P001', 1),
('O001P002', 'O001', 'P002', 1),
('O001P003', 'O001', 'P003', 2),
('O002P004', 'O002', 'P004', 3),
('O003P001', 'O003', 'P001', 2),
('O003P002', 'O003', 'P002', 1),
('O003P003', 'O003', 'P003', 3),
('O004P001', 'O004', 'P001', 1),
('O004P002', 'O004', 'P002', 1),
('O004P003', 'O004', 'P003', 1),
('O005P001', 'O005', 'P001', 1),
('O005P002', 'O005', 'P002', 3),
('O006P002', 'O006', 'P002', 2),
('O006P005', 'O006', 'P005', 1),
('O007P001', 'O007', 'P001', 1),
('O007P002', 'O007', 'P002', 1),
('O007P003', 'O007', 'P003', 1),
('O008P002', 'O008', 'P002', 1),
('O008P004', 'O008', 'P004', 1),
('O009P001', 'O009', 'P001', 1),
('O010P003', 'O010', 'P003', 1),
('O011P001', 'O011', 'P001', 1),
('O012P001', 'O012', 'P001', 1),
('O012P002', 'O012', 'P002', 1),
('O012P004', 'O012', 'P004', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` varchar(4) NOT NULL,
  `customerID` varchar(4) NOT NULL,
  `staffID` varchar(5) NOT NULL,
  `orderDate` datetime NOT NULL,
  `orderStatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `customerID`, `staffID`, `orderDate`, `orderStatus`) VALUES
('O001', 'C001', '001', '2024-06-11 00:00:00', 'payment Done'),
('O002', 'C002', '001', '2024-06-11 00:00:00', 'payment Done'),
('O003', 'C001', '001', '2024-06-11 00:00:00', 'payment Done'),
('O004', 'C005', '001', '2024-06-12 00:00:00', 'payment Done'),
('O005', 'C001', '001', '2024-06-12 00:00:00', 'payment Done'),
('O006', 'C001', '001', '2024-06-12 00:00:00', 'payment Done'),
('O007', 'C006', '001', '2024-06-22 00:00:00', 'payment Done'),
('O008', 'C001', '001', '2024-06-22 00:00:00', 'payment Done'),
('O009', 'C001', '001', '2024-06-22 00:00:00', 'payment Done'),
('O010', 'C002', '001', '2024-06-22 00:00:00', 'payment Done'),
('O011', 'C004', '001', '2024-06-22 00:00:00', 'payment Done'),
('O012', 'C006', '001', '2024-06-22 00:00:00', 'payment Done');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` varchar(4) NOT NULL,
  `productName` varchar(50) NOT NULL,
  `productType` enum('Food','Beverages','Additional') NOT NULL,
  `productPrice` decimal(10,2) NOT NULL,
  `productImg` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `productName`, `productType`, `productPrice`, `productImg`) VALUES
('P001', 'Apple Pie', 'Food', 4.99, 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Apple_pie.jpg/1024px-Apple_pie.jpg'),
('P002', 'Orange Juice', 'Beverages', 2.99, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_k3dmXxGhAIYtpo1VDWy8SJi30wQqJ5J9Ig&s'),
('P003', 'Americano', 'Beverages', 2.00, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOVs_xyc3P-9qiEKpPAAICiyBsO6SHfYkL4w&s'),
('P004', 'Jus Mangga', 'Beverages', 2.00, 'https://vaya.in/recipes/wp-content/uploads/2018/02/mango-frooti.jpg'),
('P005', 'Chicken katsu', 'Food', 4.00, 'https://feedgrump.com/wp-content/uploads/2023/05/hawaii-chicken-katsu-curry-plating-feature.jpg');

--
-- Triggers `product`
--
DELIMITER $$
CREATE TRIGGER `ValidateProductID` BEFORE INSERT ON `product` FOR EACH ROW BEGIN
    IF NEW.productID NOT REGEXP '^P[0-9]{3}$' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'productID must start with P followed by three digits.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffID` varchar(5) NOT NULL,
  `staffName` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `staffName`, `password`) VALUES
('001', 'karsten', '12345'),
('002', 'Bob Smith', 'password456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beverage`
--
ALTER TABLE `beverage`
  ADD PRIMARY KEY (`beverageID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`),
  ADD UNIQUE KEY `customerEmail` (`customerEmail`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`foodID`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`orderDetailID`),
  ADD KEY `orderID` (`orderID`),
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `customerID` (`customerID`),
  ADD KEY `staffID` (`staffID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `beverage`
--
ALTER TABLE `beverage`
  ADD CONSTRAINT `beverage_ibfk_1` FOREIGN KEY (`beverageID`) REFERENCES `product` (`productID`) ON DELETE CASCADE;

--
-- Constraints for table `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `food_ibfk_1` FOREIGN KEY (`foodID`) REFERENCES `product` (`productID`) ON DELETE CASCADE;

--
-- Constraints for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`orderID`) REFERENCES `orders` (`orderID`) ON DELETE CASCADE,
  ADD CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
